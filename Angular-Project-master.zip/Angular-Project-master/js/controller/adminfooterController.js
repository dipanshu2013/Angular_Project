slrapp.controller("AdminfooterCtrl", function($scope, $document, $firebaseObject, $http, $localStorage,cssInjector, $location) {
	
});