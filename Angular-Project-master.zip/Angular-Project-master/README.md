# Solar Energy
Angular Based project with firebase along with admin panel.



<h2>Features</h2>
<p>1. Use almost feature of angularjs i.e. <br>&nbsp;&nbsp;&nbsp;* Controller with its services and directive<br>&nbsp;&nbsp;&nbsp;* Firebase for handling real time storage engine. <br></p> 
<p>2. Manage the full angular project with systematic template engine</p> 
<p>3. Properly use of node module like Routing, Storage engine, Http, Cookie and System Monitor</p> 

<h2>How To Install</h2>
<p>It is properly managed but even if missing anything, just install the node package manager as under<br>
<h3>sudo npm install npm -g</h3><br>
Once you’ve installed Node.js, you can make sure you’ve got the very most recent version of npm using npm itself</p>

<h2>Admin Detail</h2>
<p>Admin can be accessible with the following detail....<br>
Username: admin<br>
Password: admin123<br>
You can create your own database in firebase and access globally. Make sure routing should be defined with proper way. 
</p>

<h2>Creator</h2>
<p>Pankaj Pandey</p>
<p>Facebook : https://facebook.com/topankajpandey</p>
<p>Thanks and very welcome for any kind of suggesion. Please mail me at topankajpandey@gmail.com</p> 


